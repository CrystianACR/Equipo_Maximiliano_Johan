package com.MAXIMILIANO.MAXIMILIAN

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.espresso.intent.Intents
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.rule.ActivityTestRule
import com.MAXIMILIANO.MAXIMILIAN.ui.activities.MainActivity

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*
import org.junit.Before
import org.junit.FixMethodOrder
import org.junit.Rule
import org.junit.runners.MethodSorters


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4::class)
class ExampleInstrumentedTest {
    @Rule
    var activityRule: ActivityTestRule<MainActivyty> = ActivityTestRule(MainActivity::class.java)

    @Before
    fun setUp() {
        Intents.init()
        val appContext = ApplicationProvider.getApplicationContext<Context>()
    }

    @Test
    fun useAppContext() {
        // Not enough time to implement them :(
    }
}
