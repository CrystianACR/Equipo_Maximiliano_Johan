package com.MAXIMILIANO.MAXIMILIAN.data.repositories

import android.app.Application
import android.database.sqlite.SQLiteConstraintException
import android.os.AsyncTask
import androidx.paging.DataSource
import com.MAXIMILIANO.MAXIMILIAN.api.TheMovieApiClient
import com.MAXIMILIANO.MAXIMILIAN.api.responses.GetMoviesResponse
import com.MAXIMILIANO.MAXIMILIAN.data.MovieBoundaryCallback
import com.MAXIMILIANO.MAXIMILIAN.data.db.MovviRoomDatabase
import com.MAXIMILIANO.MAXIMILIAN.data.db.daos.GenreDao
import com.MAXIMILIANO.MAXIMILIAN.data.db.daos.MovieDao
import com.MAXIMILIANO.MAXIMILIAN.data.db.daos.MovieDetailsDao
import com.MAXIMILIANO.MAXIMILIAN.data.models.Genre
import com.MAXIMILIANO.MAXIMILIAN.data.models.Movie
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MovieRepository(context: Application) {
    private val mMovieDao: MovieDao
    private val mGenreDao: GenreDao
    private val mMovieDetailsDao: MovieDetailsDao

    init {
        val db = MovviRoomDatabase.getInstance(context)
        mMovieDao = db.movieDao()
        mGenreDao = db.genreDao()
        mMovieDetailsDao = db.movieDetailsDao()
    }

    fun refresh() {
        //getPopularMovies(1)
        //getTopRatedMovies(1)
        //getUpcomingMovies(1)
        //PageUtils.resetPages()
    }

    fun getPopularMovies(page: Int) {
        TheMovieApiClient.service.getPopularMovies(TheMovieApiClient.API_KEY, page)
            .enqueue(object : Callback<GetMoviesResponse> {
                override fun onFailure(call: Call<GetMoviesResponse>, t: Throwable) {

                }

                override fun onResponse(call: Call<GetMoviesResponse>, response: Response<GetMoviesResponse>) {
                    if (response.code() == 200) {
                        val data = response.body()
                        upsert(data!!.results, MovieBoundaryCallback.LoadType.POPULAR)
                    }
                }
            })
    }

    fun getTopRatedMovies(page: Int) {
        TheMovieApiClient.service.getTopRatedMovies(TheMovieApiClient.API_KEY, page)
            .enqueue(object : Callback<GetMoviesResponse> {
                override fun onFailure(call: Call<GetMoviesResponse>, t: Throwable) {

                }

                override fun onResponse(call: Call<GetMoviesResponse>, response: Response<GetMoviesResponse>) {
                    if (response.code() == 200) {
                        val data = response.body()
                        upsert(data!!.results, MovieBoundaryCallback.LoadType.TOP_RATED)
                    }
                }
            })
    }

    fun getUpcomingMovies(page: Int) {
        TheMovieApiClient.service.getUpcomingMovies(TheMovieApiClient.API_KEY, page)
            .enqueue(object : Callback<GetMoviesResponse> {
                override fun onFailure(call: Call<GetMoviesResponse>, t: Throwable) {

                }

                override fun onResponse(call: Call<GetMoviesResponse>, response: Response<GetMoviesResponse>) {
                    if (response.code() == 200) {
                        val data = response.body()

                        upsert(data!!.results, MovieBoundaryCallback.LoadType.UPCOMING)
                    }
                }
            })
    }

    fun upsert(movies: List<Movie>, loadType: MovieBoundaryCallback.LoadType) {
        AsyncTask.execute {
            movies.forEach {movie ->
                movie.loadType = loadType.value
                val id = mMovieDao.insert(movie)
                if (id == -1L) {
                    mMovieDao.update(movie)
                }
                movie.genres.forEach {
                    val genre = Genre(it, "temporal", movie.loadType, movie.id)
                    try {
                        val genreId = mGenreDao.insert(genre)
                        if (genreId == -1L) {
                            mGenreDao.update(genre)
                        }
                    } catch (ex: SQLiteConstraintException) {
                        ex.toString()
                    }
                }
            }
        }
    }

    fun deleteAllPopular() {
        mGenreDao.deleteAllPopular()
        mMovieDetailsDao.deleteAllPopular()
        mMovieDao.deleteAllPopular()
    }

    fun deleteAllTopRated() {
        mGenreDao.deleteAllTopRated()
        mMovieDetailsDao.deleteAllTopRated()
        mMovieDao.deleteAllTopRated()
    }

    fun deleteAllUpcoming() {
        mGenreDao.deleteAllUpcoming()
        mMovieDetailsDao.deleteAllUpcoming()
        mMovieDao.deleteAllUpcoming()
    }

    fun allPopularMovies(): DataSource.Factory<Int, Movie> = mMovieDao.allPopularMovies()
    fun allTopRatedMovies(): DataSource.Factory<Int, Movie> = mMovieDao.allTopRatedMovies()
    fun allUpcomingMovies(): DataSource.Factory<Int, Movie> = mMovieDao.allUpcomingMovies()

    companion object {
        private var mInstance: MovieRepository? = null

        fun getInstance(context: Application): MovieRepository {
            if (mInstance == null) {
                mInstance = MovieRepository(context)
            }
            return mInstance as MovieRepository
        }
    }
}