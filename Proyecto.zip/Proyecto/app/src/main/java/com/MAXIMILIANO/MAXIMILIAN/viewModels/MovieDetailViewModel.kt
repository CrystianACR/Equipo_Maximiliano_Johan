package com.MAXIMILIANO.MAXIMILIAN.viewModels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.MAXIMILIANO.MAXIMILIAN.data.models.MovieDetailsRelation
import com.MAXIMILIANO.MAXIMILIAN.data.repositories.MovieDetailRepository

class MovieDetailViewModel(application: Application): AndroidViewModel(application) {
    private val dataRepository: MovieDetailRepository = MovieDetailRepository.getInstance(application)

    fun getMovieDetails(movieId: Long, loadType: Int): LiveData<MovieDetailsRelation> {
        return dataRepository.getMovieDetails(movieId, loadType)
    }
}