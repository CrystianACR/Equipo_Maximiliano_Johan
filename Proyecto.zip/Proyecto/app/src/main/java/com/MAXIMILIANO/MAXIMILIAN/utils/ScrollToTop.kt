package com.MAXIMILIANO.MAXIMILIAN.utils

class ScrollToTop(val id: Int)