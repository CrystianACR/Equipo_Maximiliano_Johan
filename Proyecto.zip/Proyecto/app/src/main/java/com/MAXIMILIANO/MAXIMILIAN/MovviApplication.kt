package com.MAXIMILIANO.MAXIMILIAN

import com.facebook.stetho.Stetho

class MovviApplication : android.app.Application() {

    override fun onCreate() {
        super.onCreate()
        Stetho.initializeWithDefaults(this)

    }
}