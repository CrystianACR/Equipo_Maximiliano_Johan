package com.MAXIMILIANO.MAXIMILIAN.ui.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.MAXIMILIANO.MAXIMILIAN.R
import com.MAXIMILIANO.MAXIMILIAN.data.models.Movie
import com.MAXIMILIANO.MAXIMILIAN.ui.activities.MovieDetailActivity
import com.MAXIMILIANO.MAXIMILIAN.utils.DateUtils
import com.google.android.material.card.MaterialCardView
import com.squareup.picasso.Picasso
import kotlin.math.roundToInt

class SearchMovieItemAdapter (
    mContext: Context,
    private var contactList: List<Movie>?)
    : RecyclerView.Adapter<SearchMovieItemAdapter.ViewHolder>(){

    private val mInflater: LayoutInflater = LayoutInflater.from(mContext)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = mInflater.inflate(R.layout.item_movie, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return contactList!!.size
    }

    fun setData(data: List<Movie>) {
        contactList = data
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.movie = contactList!![position]
        if (holder.movie != null) {
            Picasso.get()
                .load("https://image.tmdb.org/t/p/w500" + (holder.movie!!.posterPath ?: ""))
                .error(R.color.colorAccent)
                .placeholder(R.color.colorAccent)
                .into(holder.mImagePoster)
            holder.mTextTitle.text = holder.movie!!.title ?: ""
            val finalRate: Float = if (holder.movie!!.voteAverage != null) {
                holder.movie!!.voteAverage!! * 10
            } else {
                0f
            }
            val rateString = if (finalRate == 0f) {
                "N/R"
            } else {
                (finalRate).roundToInt().toString()
            }
            holder.mTextPercentage.text = rateString
            holder.mTextRelease.text = DateUtils.toSimpleString(holder.movie!!.releaseDate!!)
            holder.mTextOverview.text = holder.movie!!.overview ?: ""
        }
    }

    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        var movie: Movie? = null
        private var mCard: MaterialCardView = itemView.findViewById(R.id.background_movie_card)
        var mImagePoster: ImageView = itemView.findViewById(R.id.poster_movie_image)
        var mTextTitle: TextView = itemView.findViewById(R.id.title_movie_text)
        var mTextPercentage: TextView = itemView.findViewById(R.id.percentage_movie_text)
        var mTextOverview: TextView = itemView.findViewById(R.id.overview_movie_text)
        var mTextRelease: TextView = itemView.findViewById(R.id.release_movie_text)

        init {
            mCard.setOnClickListener { v -> openDetails(v.context) }
        }

        private fun openDetails(c: Context) {
            val intent = Intent(c, MovieDetailActivity::class.java)
            intent.putExtra(MovieDetailActivity.EXTRA_MOVIE_ID, movie!!.id)
            intent.putExtra(MovieDetailActivity.EXTRA_MOVIE_LOAD_TYPE, movie!!.loadType)
            c.startActivity(intent)
        }
    }
}