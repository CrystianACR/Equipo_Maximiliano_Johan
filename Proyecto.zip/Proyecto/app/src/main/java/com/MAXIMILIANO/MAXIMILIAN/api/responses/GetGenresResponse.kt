package com.MAXIMILIANO.MAXIMILIAN.api.responses

import com.MAXIMILIANO.MAXIMILIAN.data.models.UniqueGenre
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class GetGenresResponse(@SerializedName("genres")
                        @Expose
                        var results: List<UniqueGenre>)